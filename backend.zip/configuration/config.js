module.exports = {
    secretKey: 'myseceteykey123'
};